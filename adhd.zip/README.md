Baza danych mail: gameboyalexy@gmail.com hasło: Urb@nauta694 / narkotyki 
https://cloud.mongodb.com/v2/67b76c667c1dfc4afa05711a#/overview?connectCluster=Cluster0

Node.js 
https://nodejs.org/en/download 
komendy które użyłam do odpalenia
cd C:\Users\Pixie\Desktop\adhd-astist
node server.js
